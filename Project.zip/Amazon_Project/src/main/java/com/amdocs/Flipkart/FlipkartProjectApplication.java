package com.amdocs.Flipkart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FlipkartProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(FlipkartProjectApplication.class, args);
	}

}
