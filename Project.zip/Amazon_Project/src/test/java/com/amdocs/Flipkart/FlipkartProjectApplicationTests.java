package com.amdocs.Flipkart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlipkartProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
