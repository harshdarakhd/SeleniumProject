package com.amdocs;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class spring_demo {
	@GetMapping("/get")
	public String show() { 
		String str1="Name: Setu Singh";
		String str2 = "Unit: AQE, " + '\n' + "email: setushes@amdocs.com";
		String a = str1 + " " + str2;
		return a;
//		return "Welcome to spring";
	}
	
}
